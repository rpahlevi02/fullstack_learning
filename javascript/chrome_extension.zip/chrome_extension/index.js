let inputbtn = document.getElementById("input-btn")
const inputel = document.getElementById("input-el")
const myleads = []
let ulel = document.getElementById('ul-l')

inputbtn.addEventListener("click", function() {
    if (!myleads.includes(inputel.value) && !(inputel.value.trim() === "")) {
        myleads.push(inputel.value)
        console.log(myleads)
        renderlead()

        // clearing input
        inputel.value = ""
    }   
})

function renderlead() {
    // ulel.innerHTML = "<li><a href='" + inputel.value + "' target='blank'>" + inputel.value + "</a></li>"
    ulel.innerHTML += `<li><a href=${inputel.value} target='blank'> ${inputel.value} </a></li>`
}


